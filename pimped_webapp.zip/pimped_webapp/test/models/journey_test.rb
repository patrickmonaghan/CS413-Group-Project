require 'test_helper'

class JourneyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
