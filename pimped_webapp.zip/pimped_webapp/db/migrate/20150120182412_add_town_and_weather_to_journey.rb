class AddTownAndWeatherToJourney < ActiveRecord::Migration
  def change
    add_column :journeys, :town, :string
    add_column :journeys, :weather, :string
  end
end
