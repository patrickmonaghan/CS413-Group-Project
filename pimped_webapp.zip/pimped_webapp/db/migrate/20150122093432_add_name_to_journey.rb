class AddNameToJourney < ActiveRecord::Migration
  def change
    add_column :journeys, :name, :string
  end
end
