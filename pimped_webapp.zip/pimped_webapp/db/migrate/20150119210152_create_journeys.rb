class CreateJourneys < ActiveRecord::Migration
  def change
    create_table :journeys do |t|
      t.integer :user_id
      t.json :data

      t.timestamps null: false
    end
  end
end
