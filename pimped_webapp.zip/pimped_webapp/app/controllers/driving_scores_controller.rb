class DrivingScoresController < ApplicationController
  def index
    @users = User.all.to_a.sort! {|a, b| b.score <=> a.score}
  end
end
