class JourneysController < ApplicationController
  before_action :authenticate_user!
  def index
    @journeys = current_user.journeys
  end

  def show
    @journey = current_user.journeys.find(params[:id])
  end

  def new
    @journey = current_user.journeys.new
  end

  def create
    @journey = current_user.journeys.new
    @journey.data = JSON.parse(params[:journey][:data].read)
    @journey.name = params[:journey][:name]
    @journey.get_weather
    @journey.save
    redirect_to(@journey)
  end

  def destroy
    @journey = current_user.journeys.find(params[:id])
    @journey.destroy
    redirect_to(journeys_path)
  end
end
