class JourneyPresenter
  def initialize(journey)
    @journey = journey
  end

  def id
    @journey["id"]
  end

  def time_started
    Time.parse(@journey["time_started"])
  end

  def fuel_type
    @journey["fuel_type"]
  end

  def average_mpg
    @journey["average_mpg"]
  end

  def distance_traveled
    @journey["distance_traveled"]
  end

  def events
    @journey["events"].map {|event| EventPresenter.new(event)}
  end
end

class EventPresenter
  def initialize(event)
    @event = event
  end

  def timestamp
    Time.parse(@event["timestamp"])
  end

  def engine_rpm
    @event["engine_rpm"]
  end

  def speed
    @event["speed"].to_f.round(2)
  end

  def engine_coolant_temperature
    @event["engine_coolant_temperature"]
  end

  def engine_load_value
    @event["engine_load_value"].to_f.round(2)
  end

  def throttle_position
    @event["throttle_position"].to_f.round(2)
  end

  def ambient_air_temperature
    @event["ambient_air_temperature"]
  end

  def latitude
    @event["latitude"]
  end

  def longitude
    @event["longitude"]
  end

  def consumption
    @event["consumption"].to_f.round(2)
  end
end