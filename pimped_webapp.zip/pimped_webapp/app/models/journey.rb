class Journey < ActiveRecord::Base
  belongs_to :user

  def details
    JourneyPresenter.new(self.data)
  end

  def average_mpg
    total = self.details.events.map {|e| e.consumption}.inject(0){ |sum, el| sum + el }.to_f
    return total / self.details.events.count
  end

  def average_speed
    total = self.details.events.map {|e| e.speed}.inject(0){ |sum, el| sum + el }.to_f
    return total / self.details.events.count
  end

  def distance_traveled
    return (duration_in_hours * average_speed).round(2)
  end

  def fuel_cost
    if self.details.fuel_type == "No Data"
      fuel_type = "unleaded"
    else
      fuel_type = self.details.fuel_type.downcase.gsub(" ", "_")
    end

    cost_per_litre = PetrolPrices.get[fuel_type]
    cost_per_gallon = cost_per_litre * 4.54

    gallons_used = distance_traveled / average_mpg

    return ((gallons_used * cost_per_gallon) / 100).round(2)
  end

  def link_name
    if self.name.nil?
      return "Untitled Journey"
    else
      return self.name
    end
  end

  def duration_in_hours
    start = self.details.events.first.timestamp
    finish = self.details.events.last.timestamp
    (finish - start) / 60 / 60
  end

  def method_name

  end

  def engine_load_stats
    stats = []
    if self.details.events.length < 50
      stats = self.details.events.map {|event| event.engine_load_value.to_f.round(2)}
    else
      self.details.events.each_with_index do |event, index|
        if index.modulo(15) == 0
          stats << event.engine_load_value.to_f.round(2)
        end
      end
    end

    return stats
  end

  def consumption_stats
    stats = []
    if self.details.events.length < 50
      stats = self.details.events.map {|event| event.consumption.to_f.round(2)}
    else
      self.details.events.each_with_index do |event, index|
        if index.modulo(10) == 0
          stats << event.consumption.to_f.round(2)
        end
      end
    end

    return stats
  end

  def speed_stats
    stats = []
    if self.details.events.length < 50
      stats = self.details.events.map {|event| event.speed.to_f.round(2)}
    else
      self.details.events.each_with_index do |event, index|
        if index.modulo(10) == 0
          stats << event.speed.to_f.round(2)
        end
      end
    end

    return stats
  end

  def engine_chart
    data = {
        labels: (0...self.consumption_stats.count).to_a,
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(86,159,231,1)",
                strokeColor: "rgba(35,72,110,1)",
                pointColor: "rgba(35,72,110,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: self.consumption_stats
            }
        ]
    }
  end

  def engine_chart
    data = {
        labels: (0...self.speed_stats.count).to_a,
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(86,159,231,1)",
                strokeColor: "rgba(35,72,110,1)",
                pointColor: "rgba(35,72,110,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: self.speed_stats
            }
        ]
    }
  end

  def consumption_chart
    data = {
        labels: (0...self.engine_load_stats.count).to_a,
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(86,159,231,1)",
                strokeColor: "rgba(35,72,110,1)",
                pointColor: "rgba(35,72,110,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: self.engine_load_stats
            }
        ]
    }
  end

  def speed_chart
    data = {
        labels: (0...self.speed_stats.count).to_a,
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(86,159,231,1)",
                strokeColor: "rgba(35,72,110,1)",
                pointColor: "rgba(35,72,110,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: self.speed_stats
            }
        ]
    }
  end

  def get_weather
    if self.weather.nil? && self.town.nil?
      lat = self.details.events.first.latitude
      lon = self.details.events.first.longitude
      url = "http://api.openweathermap.org/data/2.5/weather?lat=#{lat}&lon=#{lon}"
      weather = JSON.parse(Net::HTTP.get(URI(url)))
      self.town = weather["name"]
      self.weather = weather["weather"].first["main"]
    end
  end
end
