class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  has_many :journeys

  def average_mpg
    total = self.journeys.map {|j| j.average_mpg}.inject(0) { |sum, el| sum + el }.to_f
    if journeys.length == 0
      return 0
    else
      return total / self.journeys.length
    end
  end


  def score
    score = (self.average_mpg / 10) * 2
    return score.round(0)
  end

  def username
    self.email.split("@")[0]
  end

  def score_colour
    if self.score >= 8
      return "col-md-3 green"
    elsif self.score < 8 && self.score >= 4
        return "col-md-3 amber"
    else
      return "col-md-3 red"
    end
  end
end
