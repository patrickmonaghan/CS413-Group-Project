class PetrolPrices
  def self.get
    prices = {}
    xml = Nokogiri.parse(Net::HTTP.get(URI("http://www.petrolprices.com/feeds/averages.xml")))
    xml.xpath("//Fuel").each do |fuel|
      type = fuel.attributes["type"].value.downcase.gsub(" ", "_")
      cost = fuel.children[3].text.to_f
      prices.merge!({type => cost})
    end

    return prices
  end
end